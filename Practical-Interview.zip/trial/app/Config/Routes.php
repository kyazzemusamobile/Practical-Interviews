<?php

namespace Config;

// Create a new instance of our RouteCollection class.
$routes = Services::routes();

// Load the system's routing file first, so that the app and ENVIRONMENT
// can override as needed.
if (is_file(SYSTEMPATH . 'Config/Routes.php')) {
    require SYSTEMPATH . 'Config/Routes.php';
}

/*
 * --------------------------------------------------------------------
 * Router Setup
 * --------------------------------------------------------------------
 */
$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultController('Home');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override();
//$routes['default_controller'] = 'blog';

// The Auto Routing (Legacy) is very dangerous. It is easy to create vulnerable apps
// where controller filters or CSRF protection are bypassed.
// If you don't want to define all routes, please use the Auto Routing (Improved).
// Set `$autoRoutesImproved` to true in `app/Config/Feature.php` and set the following to true.
// $routes->setAutoRoute(false);

/*
 * --------------------------------------------------------------------
 * Route Definitions
 * --------------------------------------------------------------------
 */

// We get a performance increase by specifying the default
// route since we don't have to scan directories.


$routes->get('/', 'Home::index');
$routes->match(['get', 'post'], '/taxonomy', 'Home::taxonomy');
$routes->match(['get', 'post'], '/taxonomy', 'Home::taxonomy');
$routes->match(['get', 'post'], '/myUploads', 'Home::myUploads');

$routes->match(['get', 'post'], '/my_documents', 'Home::my_documents');
$routes->match(['get', 'post'], '/trash', 'Home::trash');
$routes->match(['get', 'post'], '/Admin', 'Home::Admin');
$routes->match(['get', 'post'], '/manageUsers', 'Home::manageUsers');
$routes->match(['get', 'post'], '/tree_view', 'TreeviewController::tree_view');
$routes->match(['get', 'post'], '/tree_view2', 'TreeviewController::tree_view2');

$routes->match(['get', 'post'], '/simple', 'LoginController::simple');
$routes->match(['get', 'post'], '/auth', 'LoginController::auth');
$routes->match(['get', 'post'], '/SaveRecords', 'LoginController::SaveRecords');
$routes->match(['get', 'post'], '/SaveRecordsAppUsage', 'LoginController::SaveRecordsAppUsage');
$routes->match(['get', 'post'], '/ShowAppUsageSavedData', 'LoginController::ShowAppUsageSavedData');



$routes->match(['get', 'post'], '/show_saved_data', 'LoginController::show_saved_data');
$routes->match(['get', 'post'], '/Userloggedin', 'UserDashboardController::Userloggedin');

//Routes for Folder module
$routes->post('/store', 'FolderController::store');
$routes->post('/getFolderbyID', 'FolderController::getFolderbyID');
$routes->post('/storefile', 'FileController::storefile');
$routes->post('/updatefile', 'FileController::updatefile');
$routes->match(['get', 'post'],'/fetch_file_with_search', 'FileController::fetch_file_with_search');

$routes->get('/show_file_uploaded_by_user_id', 'FileController::show_file_uploaded_by_user_id');
$routes->post('/get_file_detailed_by_file_id', 'FileController::get_file_detailed_by_file_id');
$routes->get('/show_recent_file_uploaded_by_user_id', 'FileController::show_recent_file_uploaded_by_user_id');
$routes->get('/show_file_uploaded_by_folder_id', 'FileController::show_file_uploaded_by_folder_id');
$routes->post('/get_file_Number_with_folder_id', 'FileController::get_file_Number_with_folder_id');
$routes->post('/restore_file_details_by_file_id', 'FileController::restore_file_details_by_file_id');
 

$routes->get('/show_file_uploaded_by_user', 'FileController::show_file_uploaded_by_user');
$routes->get('/show_file_archived_by_user', 'FileController::show_file_archived_by_user');
$routes->get('/show_file_deleted_by_user', 'FileController::show_file_deleted_by_user');

$routes->post('/delete_file_details_by_file_id', 'FileController::delete_file_details_by_file_id');
$routes->post('/archive_file_details_by_file_id', 'FileController::archive_file_details_by_file_id');
$routes->post('/download_file_details_by_file_id', 'FileController::download_file_details_by_file_id');

$routes->match(['get', 'post'], '/getuserinfo', 'UserController::getuserinfo');
$routes->post('/saveuser','UserController::saveuser');
$routes->get('/showUsers','UserController::showUsers');
$routes->post('/get_user_details_by_user_id','UserController::get_user_details_by_user_id');

$routes->get('/get_user_role','UserRoleController::get_user_role');
$routes->post('/get_folder_path_with_id', 'FolderController::get_folder_path_with_id');

$routes->match(['get', 'post'], '/logout', 'LoginController::logout');


/*
 * --------------------------------------------------------------------
 * Additional Routing
 * --------------------------------------------------------------------
 *
 * There will often be times that you need additional routing and you
 * need it to be able to override any defaults in this file. Environment
 * based routes is one such time. require() additional route files here
 * to make that happen.
 *
 * You will have access to the $routes object within that file without
 * needing to reload it.
 */
if (is_file(APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php')) {
    require APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php';
}
