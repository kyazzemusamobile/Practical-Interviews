<?php namespace App\Models;  
  
use CodeIgniter\Model;
  
class AppUsagesModel extends Model{
    
    protected $table           = 'app_usage';
    protected $returnType      = 'array';
    protected $primaryKey        = 'id';
	protected $useAutoIncrement  = true;
      
    protected $useTimestamps   = true;
    protected $allowedFields   = ['group_name', 'device_name', 'group_parent', 'application', 'duration', 'mobile_data_used', 'wifi_data_used', 'status_id', 'created_by', 'created_date', 'modified_by', 'modified_date'];
    protected $dateFormat      = 'datetime';
    protected $createdField    = 'created_date';
	protected $updatedField    = 'modified_date';   
   // protected $dateFormat = 'int'; 
}