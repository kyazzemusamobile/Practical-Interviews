<?php namespace App\Models;  
  
use CodeIgniter\Model;
  
class RecordsModel extends Model{
    
    protected $table           = 'dct_record';
    protected $returnType      = 'array';
    protected $primaryKey        = 'id';
	protected $useAutoIncrement  = true;
      
    protected $useTimestamps   = true;
    protected $allowedFields   = ['name', 'title', 'gender', 'dob', 'age', 'mobile_number', 'email_address', 'luganda', 'english', 'swahili', 'been_charged', 'additional_info', 'status_id', 'created_by', 'created_date', 'modified_by', 'modified_date'];
    protected $dateFormat      = 'datetime';
    protected $createdField    = 'created_date';
	protected $updatedField    = 'modified_date';   
   // protected $dateFormat = 'int'; 
}