<?php

namespace App\Controllers;

class Home extends BaseController
{
    public function index()
    {
       // echo 'hello world';
        return view('login');
    }

    public function taxonomy()
    {
       // echo 'hello world';
        return view('taxonomy');
    }

    public function taxonomy2()
    {
       // echo 'hello world';
        return view('taxonomy2');
    }

    public function my_documents()
    {
       // echo 'hello world';
        return view('my_documents');
    }

    public function trash()
    {
       // echo 'hello world';
        return view('trash');
    }

    public function Admin()
    {
       // echo 'hello world';
        return view('Admin');
    }

    public function manageUsers()
    {
       // echo 'hello world';
        return view('manageUsers');
    }

    public function myUploads()
    {
       // echo 'hello world';
        return view('myUploads');
    }

    
}
