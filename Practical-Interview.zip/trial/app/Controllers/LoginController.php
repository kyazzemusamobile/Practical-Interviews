<?php

namespace App\Controllers;
use App\Models\UserModel;
use App\Models\FolderModel;
use App\Models\RecordsModel;
use App\Models\AppUsagesModel;

class LoginController extends BaseController
{
    public function simple(){
        echo 'hello world';
       // return view('index');
    }

    public function auth()
    {   
        $session = session();   
        $Usermodel = new UserModel();               

        $email = $this->request->getVar('username');
        $password = $this->request->getVar('password');   

        $array = ['user_name' => $email, 'password' => $password];       
        $data['user'] = $Usermodel->where($array)->first();
       
        if(count($data) > 0){ 
            session_start();  
            
            $users_data = [
                'user_id'	    => $data['user']['id'],
                'first_name'	=> $data['user']['first_name'],
                'last_name' 	=> $data['user']['last_name'],
                'user_email' 	=> $data['user']['user_email'],
                'role_id'       => $data['user']['role_id'],
                'phone_number' 	=> $data['user']['phone_number'],
                'username' 	    => $data['user']['user_name'], 
                'logged_in'     => TRUE,                              
            ]; 
           
            $session->set($users_data);
            if($data['user']['role_id'] =='5'){
                // return view('/myUploads');
                //Home::myUploads();
                return redirect()->to('/myUploads');
            }
            else if ($data['user']['role_id']=='1'){
                //return view('/Admin');
                //Home::manageUsers();
                return redirect()->to('/manageUsers');
            }                                          
        } 
        else{
            $session->setFlashdata('msg', 'Email does not exist.');
            return redirect()->to('/');
        } 
        
            //return $this->response->setJSON($data);    
    }  

    public function SaveRecordsAppUsage(){
        
        $request = \Config\Services::request();
        $AppUsagesModels = new AppUsagesModel();  
        $currentdate = date('Y-m-d H:i:s', time());   
        
        $group_name = $this->request->getVar('group_name');
        $device_name = $this->request->getVar('device_name'); 
        $group_parent = $this->request->getVar('group_parent'); 
        $application = $this->request->getVar('application');    
        $duration = $this->request->getVar('duration');         
        $mobile_data_used = $this->request->getVar('mobile_data_used');  
        $wifi_data_used = $this->request->getVar('wifi_data_used');   
             
        $data = [
            'group_name' => $group_name, //$name,
            'device_name' => $device_name, 
            'group_parent' => $group_parent,             
            'application' => $application, 

            'duration' 	=> $this->request->getVar('duration'),
            'mobile_data_used' 	=> $this->request->getVar('mobile_data_used'),
            'wifi_data_used' 	=> $this->request->getVar('wifi_data_used'),

            'status_id'     => 1,
            'created_date'  => $currentdate                                      
        ]; 

        $AppUsagesModels->save($data);
        //$data = ['status' => 'Details Saved Successfully'];
        //return $this->response->setJSON($data);  
        echo 'Details Saved Successfully';
        return redirect()->to('/');       
    } 

         // show dataTable
    public function show_saved_data(){ 

        $array = ['status_id' => 1];
        $RecordsModel = new RecordsModel(); 
        $RecordsModel->select('id, group_name, device_name, group_parent, application, duration, mobile_data_used, wifi_data_used ');
                
        $RecordsModel->where($array);
        $data = $RecordsModel->findAll();
        return $this->response->setJSON($data); 
    }

    public function ShowAppUsageSavedData(){ 

        $array = ['status_id' => 1];   
        $AppUsagesModels = new AppUsagesModel();  
        $AppUsagesModels->select('id, group_name, device_name, group_parent, application, duration, mobile_data_used, wifi_data_used','created_date');
                
        $AppUsagesModels->where($array);
        $data = $AppUsagesModels->findAll();
        return $this->response->setJSON($data); 
    }
               

    public function logout()
    {
        $session = session();
        $session->destroy();
        return redirect()->to('/');
    }
  
}