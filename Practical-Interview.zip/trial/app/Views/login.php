<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- <link rel="icon" href="<?php echo base_url();?>/images/eDoc-icon32x32.ico" type="image/icon"> -->
    <title>CoreElite Consulting | eDoc </title>

    <!-- Bootstrap -->
    <link href="<?php echo base_url('public/assets/vendors/bootstrap/dist/css/bootstrap.min.css');?>" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="<?php echo base_url('public/assets/vendors/font-awesome/css/font-awesome.min.css');?>" rel="stylesheet">
    <!-- NProgress -->
    <link href="<?php echo base_url('public/assets/vendors/nprogress/nprogress.css');?>" rel="stylesheet">
    <!-- Animate.css -->
    <link href="<?php echo base_url('public/assets/vendors/animate.css/animate.min.css');?>" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="<?php echo base_url('public/assets/build/css/custom.min.css');?>" rel="stylesheet">
    
    <!--Include Jquery-->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <!--Include Bootstrap-->
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
  
  </head>

  <body class="login">
    <div>
      <a class="hiddenanchor" id="signup"></a>
      <a class="hiddenanchor" id="signin"></a>

      <div class="login_wrapper">
        <div class="animate form login_form">
          <section class="login_content">
           
							<div class="x_panel">
								<div class="x_title">
									<h2>App Usage Data Collection </h2>
									<ul class="nav navbar-right panel_toolbox">										
										</li>										
									</ul>
									<div class="clearfix"></div>
								</div>
								<div class="x_content">

									<!-- start form for validation -->
									<form action="<?php echo base_url('/SaveRecordsAppUsage');?>" method="post">
                    <p>                    		
                    <label for="title">Device Name *:</label>
                          <select id="device_name" name="device_name" class="form-control" required>
                            <option value="">Choose..</option>
                            <option value="Mr.">Mr.</option>
                            <option value="Mrs.">Mrs.</option>
                            <option value="Miss">Miss</option>
                          </select>                        
                      </p>

                      <p>
                        <label for="title">Group Name *:</label>
                          <select id="group_name" name="group_name" class="form-control" required>
                            <option value="">Choose..</option>
                            <option value="Mr.">Mr.</option>
                            <option value="Mrs.">Mrs.</option>
                            <option value="Miss">Miss</option>
                          </select>                        
                      </p>
                      <p>
                    
                    <label for="title"> Group Parent *:</label>
                          <select id="group_parent" name="group_parent" class="form-control" required>
                            <option value="">Choose..</option>
                            <option value="Mr.">Mr.</option>
                            <option value="Mrs.">Mrs.</option>
                            <option value="Miss">Miss</option>
                          </select>                        
                      </p>

                  <p>                        
                    <label for="title">Application *:</label>
												<select id="application" name="application" class="form-control" required>
													<option value="">Choose..</option>
													<option value="Mr.">Mr.</option>
													<option value="Mrs.">Mrs.</option>
													<option value="Miss">Miss</option>
												</select>                        
                    </p>

                    <label for="phone">Duration * :</label>
										<input type="tel" id="duration" class="form-control" name="duration" data-parsley-trigger="change" required/>
                    
                    <label for="phone">Mobile Data Used:</label>
										<input type="tel" id="mobile_data_used" class="form-control" name="mobile_data_used" data-parsley-trigger="change" required/>
              
                    <label for="phone">	Wifi Data Used:</label>
										<input type="tel" id="wifi_data_used" class="form-control" name="wifi_data_used" data-parsley-trigger="change" required/>
              
                        <div class="form-group">
											<div class="col-md-9 col-sm-9  offset-md-3">
												 <button type="button" class="btn btn-primary">Cancel</button> 
												<button type="submit" class="btn btn-success ajaxlogin-submit">Submit</button>
											</div>
										</div>
                       
                      <div class="clearfix"></div>

                        <div class="separator">
                          <!-- <p class=""> 
                            <a href="#signup" class="to_register" font="200%" bond="True"> Saved Records </a>
                          </p> -->
                          
                    <div class="clearfix"></div>
									</form>
									<!-- end form for validations -->
								</div>
							</div>
           
          </section>
        </div>

        <div id="register" class="animate form registration_form">
          <section class="login_content">
            <form>
              <h1>Saved Data</h1>

              <table id="example" class="table table-striped" style="width:100%">
                <colgroup>
                    <col span="1" style="visibility: collapse">
                </colgroup>
                  <thead>
                    <tr>                 
                      <th>ID</th>
                      <th>Group Name</th>
                      <th>Device Name</th>   
                      <th>Group Parent</th>                     
                      <th>Application</th>
                      <th>Duration</th>
                      <th>Mobile Data Used</th>
                      <th>Wifi Data Used</th>
                      <th>Created Date</th>                                           
                    </tr>
                  </thead>
                  <tbody>
                  <tbody id = "tableDataUsageItem" name="tableDataUsageItem">
                  </tbody>
                  <div id='pagination'></div>
                </table>

              <div class="clearfix"></div>
              <div class="separator">
              <button type='submit' class="btn btn-primary ajaxlogin-submitCSV">Export to CSV</button>
              <!-- <button type='submit' class="btn btn-primary ajaxlogin-submitEXCEL">Export to EXCEL</button> -->

              <div class="clearfix"></div>
              <div class="separator">
                <p>
                  <a href="#signin" class="to_register"> Create more record </a>
                </p>

                <div class="clearfix"></div>
                <br />
              </div>
            </form>
          </section>
        </div>
      </div>
    </div>
    <script>     
     $(document).ready(function(){
      ShowSavedUsageData();
      //show_App_usage_saved_data()
      $("div#explain").hide();

      $('.ajaxlogin-submitCSV').click(function() {  
            var titles = [];
            var data = [];
            
              $('.table tr').each(function() {
                      data.push($(this));
                  });
              csv_data = []
            data.forEach(function(item,index){
              td = item[0].children
              for(i=0;i<td.length;i++){                
                csv_data.push(td[i].innerText)
              }              
              csv_data.push('\r\n')
            })

            var downloadLink = document.createElement("a");
            var blob = new Blob(["\ufeff", csv_data]);
            var url = URL.createObjectURL(blob);
            downloadLink.href = url;
            downloadLink.download = "SavedRecords.xls";
            document.body.appendChild(downloadLink);
            downloadLink.click();
            document.body.removeChild(downloadLink);

        })


     function ShowSavedUsageData() {    
      var id = 1;
      $.ajax({
          url: "<?php echo base_url('/ShowAppUsageSavedData');?>",
          type: 'POST',
          // what data you passing.
          data: {
              'id' : id
          },
          processData: false,
          contentType: false,
          dataType: 'json',
          success: function(response) {
            //console.log("data is here", response);
              var str = "";
            for (var i = 0; i < response.length; i++) {
                var object = response[i];

                str = str + "<tr> \
                    <td>"+object.group_name+"</td> \
                    <td>"+object.device_name+"</td> \
                    <td>"+object.group_parent + "</td> \
                    <td>"+object.application + "</td> \
                    <td>"+object.duration + "</td> \
                    <td>"+object.mobile_data_used + "</td> \
                    <td>"+object.wifi_data_used + "</td> \
                    <td>"+object.created_date + "</td> \
                    <td class='btn btn-warning btn-sm btn-edit' data-id='"+ object.id + "'><span class='fa fa-view'></span></a>Edit</td>\
                   </tr/>";
            }
            list = response;
            $("#tableDataUsageItem").html("");
            $("#tableDataUsageItem").html(str);
           // $("#listloader").addClass("hide");
          }
      });
    }

    // get View Product
    $(document).on('click','.btn-edit',function(e) {
        var ids = $(this).data('id');               
       $.ajax({
         url: "<?php echo base_url('/get_user_details_by_user_id');?>",
         type:"POST",
         data:{
              'id' : ids          
          },
          dataType:"json",
         success: function({user}) {
          Array.from(user).forEach(e=>{
            //console.log("data is here2", e);                  
              $('[name="UserItemId"]').val(e.id);          
              $('[name="updatefirstname"]').val(e.first_name);
              $('[name="updatelastname"]').val(e.last_name);
              $('[name="updateuser_role_id"]').val(e.role_id);
              $('[name="updateemail"]').val(e.user_email);
              $('[name="updateoccupation"]').val(e.designation); 
              $('[name="updatephone_number"]').val(e.phone_number); 
            })   

            $('.updatepassword').attr('disabled','disabled');
            $('.updatepassword1').attr('disabled','disabled'); 
                                
             ShowUpdateFileModalform();
          },
         error: function(jqXHR, textStatus, errorThrown) {
           alert('Error get data from ajax');
         }
       });
       
    });


      $("#dob").change(function(){
          var today = new Date();
          var birthDate = new Date($('#dob').val());
          var age = today.getFullYear() - birthDate.getFullYear();
          var m = today.getMonth() - birthDate.getMonth();
          if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
              age--;
          }
          $("#age").val(age);
          //return $('.age').html(age+' years old');
      });

      $('#offence').change(function () {
        if ($(this).is(':checked')) {
            $("div#explain").show();           
        } else {
            
            $("div#explain").hide();
        }
    });
        
    });
   
   </script>
  </body>
</html>
