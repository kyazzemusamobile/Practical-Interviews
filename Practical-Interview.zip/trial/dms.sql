-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 06, 2022 at 05:26 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dms`
--

-- --------------------------------------------------------

--
-- Table structure for table `document`
--

CREATE TABLE `document` (
  `id` int(11) NOT NULL,
  `document_number` varchar(50) NOT NULL,
  `folder_id` int(15) DEFAULT NULL,
  `document_name` varchar(300) DEFAULT NULL,
  `key_words` varchar(300) DEFAULT NULL,
  `key_word` varchar(500) DEFAULT NULL,
  `short_form` varchar(50) DEFAULT NULL,
  `document_description` varchar(300) DEFAULT NULL,
  `file_size` int(15) DEFAULT NULL,
  `document_is_deleted` int(11) DEFAULT NULL,
  `deleted_date` datetime DEFAULT NULL,
  `document_is_archive` int(11) DEFAULT NULL,
  `archived_date` datetime DEFAULT NULL,
  `file_type` varchar(150) DEFAULT NULL,
  `file_path` varchar(250) DEFAULT NULL,
  `status_id` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_date` datetime DEFAULT current_timestamp(),
  `modified_by` int(11) DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `document`
--

INSERT INTO `document` (`id`, `document_number`, `folder_id`, `document_name`, `key_words`, `key_word`, `short_form`, `document_description`, `file_size`, `document_is_deleted`, `deleted_date`, `document_is_archive`, `archived_date`, `file_type`, `file_path`, `status_id`, `created_by`, `created_date`, `modified_by`, `modified_date`) VALUES
(9, '324324324', 48, 'yydgffsfd', 'werewr', NULL, 'YY', 'sdfdsfds sfdsfdsfds', 95382, 1, '2022-12-03 09:25:04', NULL, NULL, 'application/pdf', 'public/storage-folder/undefined', 0, 1, '2022-11-07 11:08:42', NULL, '2022-12-03 09:25:04'),
(10, '57577', 50, 'ghgjwer', 'trttry', NULL, 'GHG', 'Kyazze Kyazze Kyazze Kyazze Kyazze Kyazze ', 95382, NULL, NULL, NULL, NULL, 'application/pdf', 'public/storage-folder/undefined', 1, 1, '2022-11-07 11:12:15', NULL, '2022-11-07 11:12:15'),
(11, 'erewrew', 52, 'ewrwrew', 'Kcca:Tucksee:yummy', 'Kcca:Tucksee:yummy', 'EWR', 'dsfsdfdf', 95382, 1, '2020-11-22 08:27:44', 1, NULL, 'application/pdf', 'public/storage-folder/ewrwrew', 1, 1, '2022-11-07 11:16:26', 1, '0000-00-00 00:00:00'),
(12, '34324324', 49, 'dgdgdfgd', 'ewwer', NULL, 'DGD', 'dfgfdgfdgfd dgfdgfdg fdgg', 95382, NULL, NULL, NULL, NULL, 'application/pdf', 'public/storage-folder/dgdgdfgd', 1, 1, '2022-11-07 11:21:25', NULL, '2022-11-07 11:21:25'),
(13, '324324', 50, '23wrewrew', 'fdfdsf', NULL, 'WRE', 'etretret  retretret retretre', 2171331, NULL, NULL, 1, '2022-12-03 09:25:19', 'application/pdf', 'public/storage-folder/23wrewrew.pdf', 0, 1, '2022-11-09 11:32:01', NULL, '2022-12-03 09:25:19'),
(14, 'TH/UY/PRO/PO/6', 35, 'Tucksee', NULL, NULL, NULL, '', 2171331, NULL, NULL, NULL, '0000-00-00 00:00:00', 'application/pdf', 'public/storage-folder/Tucksee.pdf', 1, 1, '2022-11-16 14:35:57', NULL, '2022-12-03 09:24:06'),
(15, 'TH/UY/ERR/FO/7', 70, 'PTMS KCCA', NULL, NULL, NULL, 'uganda 3eewrewr', 924519, NULL, NULL, NULL, NULL, 'application/pdf', 'public/storage-folder/PTMS .pdf', 1, 1, '2022-11-21 10:28:26', 1, '2022-11-22 16:06:15'),
(16, 'TH/UY/PRO/8', 34, 'Frame work', 'ewrwer:ewfewf:dsfdsf', NULL, NULL, 'uganda', 924519, NULL, NULL, NULL, NULL, 'application/pdf', 'public/storage-folder/Frame work.pdf', 1, 1, '2022-11-22 02:47:31', 1, '2022-11-22 02:47:48'),
(17, 'TH/UY/PRO/PO/HIT/9', 52, 'framework', NULL, NULL, NULL, 'yuui', 924519, NULL, NULL, NULL, NULL, 'application/pdf', 'public/storage-folder/framework.pdf', 1, 1, '2022-11-22 02:55:16', 1, '2022-11-22 11:17:24'),
(18, 'TH/UY/PRO/PO/HIT/10', 52, 'framework', NULL, NULL, NULL, 'framework 666666', 924519, 1, '2022-12-03 09:24:25', 1, '2022-12-02 07:50:20', 'application/pdf', 'public/storage-folder/framework.pdf', 0, 1, '2022-11-22 02:55:25', 1, '2022-12-03 09:24:25'),
(19, 'TH/UY/PRO/PO/HIT/MyF/11', 71, 'Kcca Tucksee', 'uganda', NULL, NULL, 'Tucksee Uganda mmmmmmm', 2171331, NULL, NULL, NULL, NULL, 'application/pdf', 'public/storage-folder/Kcca Tucksee.pdf', 1, 1, '2022-11-22 15:29:35', 1, '2022-11-27 04:13:07'),
(20, 'TH/UY/PRO/PO/HIT/MyF/11', 71, 'Kcca Tucksee', NULL, NULL, NULL, 'Tucksee Uganda', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, '2022-11-22 15:42:54', 1, '2022-11-22 15:42:54'),
(21, 'TH/UY/PRO/PO/HIT/MyF/11', 71, 'Kcca Tucksee', NULL, NULL, NULL, 'Tucksee Uganda', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, '2022-11-22 15:43:14', 1, '2022-11-22 15:43:14'),
(22, 'TH/UY/PRO/PO/HIT/MyF/11', 71, 'Kcca Tucksee', NULL, NULL, NULL, 'Tucksee Uganda hhhhhhhhhh', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, '2022-11-22 15:47:51', 1, '2022-11-22 15:47:51'),
(23, 'TH/UY/PRO/PO/HIT/10', NULL, 'framework', NULL, NULL, NULL, 'framework 666666 yyyyy', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, '2022-11-22 15:55:41', 1, '2022-11-22 15:55:41'),
(24, 'TH/GEO/ND3/16', 69, 'esrewrew', 'gfdg:dsfs:fdsdf', NULL, NULL, 'ewrewr esrewrew ererewr', 2171331, NULL, NULL, NULL, NULL, 'application/pdf', 'public/storage-folder/esrewrew.pdf', 1, 1, '2022-11-22 15:58:08', 1, '0000-00-00 00:00:00'),
(25, 'TH/GEO/ND3/16', NULL, 'esrewrew', NULL, NULL, NULL, 'ewrewr esrewrew', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, '2022-11-22 15:59:30', 1, '2022-11-22 15:59:30'),
(26, 'TH/UY/PRO/PO/HIT/18', 52, 'Personal file', 'File', NULL, NULL, 'Personal file', 2171331, 1, '2022-11-27 04:21:37', 1, '2022-11-27 04:21:02', 'application/pdf', 'public/storage-folder/Personal file.pdf', 1, 1, '2022-11-23 04:10:16', NULL, '2022-11-27 04:21:37');

-- --------------------------------------------------------

--
-- Table structure for table `document_permission`
--

CREATE TABLE `document_permission` (
  `document_permission_id` int(11) NOT NULL,
  `document_permission_name` varchar(255) DEFAULT NULL,
  `document_permission_description` varchar(300) DEFAULT NULL,
  `document_permission_status_id` int(11) DEFAULT NULL,
  `document_permission_created_by` varchar(255) DEFAULT NULL,
  `document_permission_created_date` datetime NOT NULL DEFAULT current_timestamp(),
  `document_permission_modified_by` varchar(255) DEFAULT NULL,
  `document_permission_modified_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `document_taxonomy`
--

CREATE TABLE `document_taxonomy` (
  `document_taxonomy_level` int(11) NOT NULL,
  `taxonomy_id` int(11) DEFAULT NULL,
  `document_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `status_id` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_date` datetime NOT NULL DEFAULT current_timestamp(),
  `modified_by` int(11) DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `file_type`
--

CREATE TABLE `file_type` (
  `file_type_id` int(11) NOT NULL,
  `file_type_name` varchar(250) DEFAULT NULL,
  `file_type_status_id` int(11) DEFAULT NULL,
  `file_type_created_by` int(11) DEFAULT NULL,
  `file_type_created_date` datetime NOT NULL,
  `file_type_modified_by` int(11) DEFAULT NULL,
  `file_type_modified_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `folder`
--

CREATE TABLE `folder` (
  `id` int(50) NOT NULL,
  `level_id` int(11) DEFAULT NULL,
  `addbothfilesfolders` bit(1) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `name` varchar(250) DEFAULT NULL,
  `short_form` varchar(250) DEFAULT NULL,
  `description` varchar(300) DEFAULT NULL,
  `status_id` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_date` datetime NOT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `folder`
--

INSERT INTO `folder` (`id`, `level_id`, `addbothfilesfolders`, `parent_id`, `name`, `short_form`, `description`, `status_id`, `created_by`, `created_date`, `modified_by`, `modified_date`) VALUES
(31, NULL, NULL, 0, 'Root', 'RT', 'task1title', NULL, NULL, '2022-11-06 05:31:52', NULL, NULL),
(32, NULL, NULL, 31, 'task2', 'TH', 'task2title', NULL, NULL, '2022-11-06 05:31:52', NULL, NULL),
(33, NULL, NULL, 32, 'task3', 'UY', 'task1title3', NULL, NULL, '2022-11-06 05:31:52', NULL, NULL),
(34, NULL, NULL, 33, 'task4', 'PRO', 'task2title4', NULL, NULL, '2022-11-06 05:31:52', NULL, NULL),
(35, NULL, NULL, 34, 'task5', 'PO', 'task5', NULL, NULL, '2022-11-06 05:31:52', NULL, NULL),
(48, NULL, NULL, 31, 'tyttuyuu', 'PHY', 'tyttuyuu', NULL, NULL, '2022-11-06 05:31:52', NULL, NULL),
(49, NULL, NULL, 31, 'New node', 'HK', 'New node', NULL, NULL, '2022-11-06 05:31:52', NULL, NULL),
(50, NULL, NULL, 31, 'New node', 'PL', 'New node', NULL, NULL, '2022-11-06 05:31:52', NULL, NULL),
(51, NULL, NULL, 32, 'New node', 'GEO', 'New node', NULL, NULL, '2022-11-06 05:31:52', NULL, NULL),
(52, NULL, NULL, 35, 'New node', 'HIT', 'New node', NULL, NULL, '2022-11-06 05:31:52', NULL, NULL),
(53, NULL, NULL, 31, 'New node', 'AY', 'New node', NULL, NULL, '2022-11-06 05:31:52', NULL, NULL),
(54, NULL, NULL, 33, 'New node', 'ERR', 'New node', NULL, NULL, '2022-11-06 05:31:52', NULL, NULL),
(55, NULL, NULL, 32, 'New node', 'LOP', 'New node', NULL, NULL, '2022-11-06 05:31:52', NULL, NULL),
(56, NULL, NULL, 48, 'yhsjfhdshfjds', 'KPL', 'weewhruewhr uiewhrewur', 1, 11, '2022-11-06 05:31:52', NULL, '2022-11-06 05:31:52'),
(58, NULL, NULL, 53, 'Procurement Directory', 'HP', 'Folder to have all procurement files', 1, 11, '2022-11-15 15:55:04', NULL, '2022-11-15 15:55:04'),
(69, NULL, NULL, 51, 'node folders 3', 'ND3', 'node files folders 3', 1, 11, '2022-11-20 06:52:55', NULL, '2022-11-20 06:52:55'),
(70, NULL, NULL, 54, 'Files others', 'FO', 'node folders 3 node folders 3', 1, 11, '2022-11-20 06:53:55', NULL, '2022-11-20 06:53:55'),
(71, NULL, NULL, 52, 'My folder', 'MyF', 'My folder', 1, 11, '2022-11-22 03:15:28', NULL, '2022-11-22 03:15:28'),
(72, NULL, NULL, 34, 'My folder2', 'Myf2', 'My folder', 1, 11, '2022-11-22 03:17:47', NULL, '2022-11-22 03:17:47'),
(73, NULL, NULL, 33, 'My folder test', 'FLD', 'test folder', 1, 11, '2022-11-22 16:12:19', NULL, '2022-11-22 16:12:19'),
(78, NULL, b'1', 73, 'Money', 'man moon', 'dsfsdf dsfsdfdsf', 1, 11, '2022-11-22 16:38:36', NULL, '2022-11-22 16:38:36'),
(79, NULL, b'1', 35, 'dsfdsfds', 'dsfdsf', 'sdfdsfds dsfdsfds', 1, 11, '2022-11-22 16:40:12', NULL, '2022-11-22 16:40:12');

-- --------------------------------------------------------

--
-- Table structure for table `key_word`
--

CREATE TABLE `key_word` (
  `key_word_id` int(11) NOT NULL,
  `key_word_name` varchar(250) NOT NULL,
  `document_id` int(11) NOT NULL,
  `key_word_status_id` int(11) NOT NULL,
  `key_word_created_by` int(11) NOT NULL,
  `key_word_created_date` datetime DEFAULT current_timestamp(),
  `key_word_modified_by` int(11) DEFAULT NULL,
  `key_word_modified_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `level`
--

CREATE TABLE `level` (
  `id` int(11) NOT NULL,
  `level` text DEFAULT NULL,
  `status_id` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_datetime` datetime DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `level`
--

INSERT INTO `level` (`id`, `level`, `status_id`, `created_by`, `created_datetime`, `modified_by`, `modified_date`) VALUES
(1, 'Main', 1, NULL, '2022-11-02 00:00:00', NULL, NULL),
(1, 'Main', 1, NULL, '2022-11-02 00:00:00', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `my_favourite`
--

CREATE TABLE `my_favourite` (
  `document_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `my_favourite_created` datetime DEFAULT NULL,
  `my_favourite_status_id` int(11) DEFAULT NULL,
  `my_favourite_created_date` datetime NOT NULL DEFAULT current_timestamp(),
  `my_favourite_created_by` int(11) DEFAULT NULL,
  `my_favourite_modified_by` int(11) DEFAULT NULL,
  `my_favourite_modified_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `taxonomy_level1`
--

CREATE TABLE `taxonomy_level1` (
  `Taxonomy_level1_id` int(11) NOT NULL,
  `Taxonomy_level1_name` varchar(250) NOT NULL,
  `Taxonomy_level1_description` int(11) DEFAULT NULL,
  `Taxonomy_root_id` int(11) DEFAULT NULL,
  `created_datetime` datetime NOT NULL DEFAULT current_timestamp(),
  `created_by_id` int(11) NOT NULL,
  `allow_file_attachment` tinyint(1) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `taxonomy_level2`
--

CREATE TABLE `taxonomy_level2` (
  `Taxonomy_level2_id` int(11) NOT NULL,
  `Taxonomy_level2_name` varchar(250) NOT NULL,
  `Taxonomy_level2_description` int(11) DEFAULT NULL,
  `Taxonomy_root_id` int(11) DEFAULT NULL,
  `created_datetime` datetime NOT NULL DEFAULT current_timestamp(),
  `created_by_id` int(11) NOT NULL,
  `allow_file_attachment` tinyint(1) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `taxonomy_level3`
--

CREATE TABLE `taxonomy_level3` (
  `Taxonomy_level3_id` int(11) NOT NULL,
  `Taxonomy_level3_name` varchar(250) NOT NULL,
  `Taxonomy_level3_description` int(11) DEFAULT NULL,
  `Taxonomy_root_id` int(11) DEFAULT NULL,
  `created_datetime` datetime NOT NULL DEFAULT current_timestamp(),
  `created_by_id` int(11) NOT NULL,
  `allow_file_attachment` tinyint(1) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `taxonomy_level4`
--

CREATE TABLE `taxonomy_level4` (
  `Taxonomy_level4_id` int(11) NOT NULL,
  `Taxonomy_level4_name` varchar(250) NOT NULL,
  `Taxonomy_level4_description` int(11) DEFAULT NULL,
  `Taxonomy_root_id` int(11) DEFAULT NULL,
  `created_datetime` datetime NOT NULL DEFAULT current_timestamp(),
  `created_by_id` int(11) NOT NULL,
  `allow_file_attachment` tinyint(1) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `taxonomy_level5`
--

CREATE TABLE `taxonomy_level5` (
  `Taxonomy_level5_id` int(11) NOT NULL,
  `Taxonomy_level5_name` varchar(250) NOT NULL,
  `Taxonomy_level5_description` int(11) DEFAULT NULL,
  `Taxonomy_root_id` int(11) DEFAULT NULL,
  `created_datetime` datetime NOT NULL DEFAULT current_timestamp(),
  `created_by_id` int(11) NOT NULL,
  `allow_file_attachment` tinyint(1) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `taxonomy_level6`
--

CREATE TABLE `taxonomy_level6` (
  `Taxonomy_level6_id` int(11) NOT NULL,
  `Taxonomy_level6_name` varchar(250) NOT NULL,
  `Taxonomy_level6_description` int(11) DEFAULT NULL,
  `Taxonomy_root_id` int(11) DEFAULT NULL,
  `created_datetime` datetime NOT NULL DEFAULT current_timestamp(),
  `created_by_id` int(11) NOT NULL,
  `allow_file_attachment` tinyint(1) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `taxonomy_level7`
--

CREATE TABLE `taxonomy_level7` (
  `Taxonomy_level7_id` int(11) NOT NULL,
  `Taxonomy_level7_name` varchar(250) NOT NULL,
  `Taxonomy_level7_description` int(11) DEFAULT NULL,
  `Taxonomy_root_id` int(11) DEFAULT NULL,
  `created_datetime` datetime NOT NULL DEFAULT current_timestamp(),
  `created_by_id` int(11) NOT NULL,
  `allow_file_attachment` tinyint(1) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `taxonomy_level8`
--

CREATE TABLE `taxonomy_level8` (
  `Taxonomy_level8_id` int(11) NOT NULL,
  `Taxonomy_level8_name` varchar(250) NOT NULL,
  `Taxonomy_level8_description` int(11) DEFAULT NULL,
  `Taxonomy_root_id` int(11) DEFAULT NULL,
  `created_datetime` datetime NOT NULL DEFAULT current_timestamp(),
  `created_by_id` int(11) NOT NULL,
  `allow_file_attachment` tinyint(1) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `taxonomy_level9`
--

CREATE TABLE `taxonomy_level9` (
  `Taxonomy_level9_id` int(11) NOT NULL,
  `Taxonomy_level9_name` varchar(250) NOT NULL,
  `Taxonomy_level9_description` int(11) DEFAULT NULL,
  `Taxonomy_root_id` int(11) DEFAULT NULL,
  `created_datetime` datetime NOT NULL DEFAULT current_timestamp(),
  `created_by_id` int(11) NOT NULL,
  `allow_file_attachment` tinyint(1) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `taxonomy_level10`
--

CREATE TABLE `taxonomy_level10` (
  `Taxonomy_level10_id` int(11) NOT NULL,
  `Taxonomy_level10_name` varchar(250) NOT NULL,
  `Taxonomy_level10_description` int(11) DEFAULT NULL,
  `Taxonomy_root_id` int(11) DEFAULT NULL,
  `created_datetime` datetime NOT NULL DEFAULT current_timestamp(),
  `created_by_id` int(11) NOT NULL,
  `allow_file_attachment` tinyint(1) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `taxonomy_root`
--

CREATE TABLE `taxonomy_root` (
  `Taxonomy_root_id` int(11) NOT NULL,
  `Taxonomy_root_name` varchar(250) NOT NULL,
  `Taxonomy_root_description` int(11) DEFAULT NULL,
  `created_datetime` datetime NOT NULL DEFAULT current_timestamp(),
  `created_by_id` int(11) DEFAULT NULL,
  `allow_file_attachment` tinyint(1) DEFAULT NULL,
  `status_id` int(11) DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(25) NOT NULL,
  `user_name` varchar(250) DEFAULT NULL,
  `first_name` varchar(250) DEFAULT NULL,
  `last_name` varchar(250) DEFAULT NULL,
  `role_id` int(25) DEFAULT NULL,
  `user_email` varchar(250) NOT NULL,
  `designation` varchar(250) DEFAULT NULL,
  `phone_number` varchar(50) DEFAULT NULL,
  `password` varchar(250) DEFAULT NULL,
  `status_id` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `user_name`, `first_name`, `last_name`, `role_id`, `user_email`, `designation`, `phone_number`, `password`, `status_id`, `created_by`, `created_date`, `modified_by`, `modified_date`) VALUES
(1, 'sadsadsa', '\\ssad', 'dsadsadsa', 1, 'sadsadsa', 'asdsadsa', '0782896512', '1234', 1, 1, '2022-11-13 04:31:06', NULL, '2022-11-13 04:31:06'),
(2, 'rtretre', 'tetret', 'retret', 3, 'rtretre', 'retretre', '435435', '1234', 1, 1, '2022-11-13 04:32:10', NULL, '2022-11-13 04:32:10'),
(3, 'fdgfdgfd', 'dfgfdg', 'fdgfdg', 1, 'fdgfdgfd', 'fdgfdgfd', '0782896512', '1234', 1, 1, '2022-11-13 05:32:32', NULL, '2022-11-13 05:32:32'),
(5, 'kyazzemusa@gmail.com', 'Musa', 'kyazze', 5, 'kyazzemusa@gmail.com', 'gfdgfdgd', '0782896512', '1234', 1, 1, '2022-11-17 06:12:41', NULL, '2022-11-17 06:12:41'),
(8, 'kyazzemusa2@gmail.com', 'Musa', 'kyazze', 1, 'kyazzemusa2@gmail.com', 'users', '0782896512', '1234', 1, 1, '2022-11-17 09:07:30', NULL, '2022-11-17 09:07:30'),
(9, 'wabendo@gmail.com', 'Fred', 'wabendo', 1, 'wabendo@gmail.com', 'user', '0782896512', '1234', 1, 1, '2022-11-17 09:11:48', NULL, '2022-11-17 09:11:48'),
(10, 'eertret', 'ettrt', 'ertretre', 6, 'eertret', 'tretret', '0782896512', '1234', 1, 1, '2022-11-17 09:16:14', NULL, '2022-11-17 09:16:14'),
(11, 'sw@hm.com', 'Swawa', 'Minor', 1, 'sw@hm.com', 'rer', '0700132461', '1234', 1, 1, '2022-11-17 09:18:39', NULL, '2022-11-17 09:18:39'),
(12, 'retret', 'ertret', 'eert', 3, 'retret', 'retre', '324324234', '1234', 1, 1, '2022-11-17 09:20:51', NULL, '2022-11-17 09:20:51'),
(13, 'ewrew', 'wrewr', 'ewrewr', 6, 'ewrew', 'ewrewr', '2321321', '1234', 1, 1, '2022-11-17 09:23:59', NULL, '2022-11-17 09:23:59'),
(14, 'ma@kk.com', 'Malcom', 'Kawooya', 1, 'ma@kk.com', 'Developer', '3435435', '1234', 1, 1, '2022-11-17 09:27:35', NULL, '2022-11-17 09:27:35'),
(15, 'rd@nm.vim', 'Richard', 'Ndagimana', 1, 'rd@nm.vim', 'IT', '3232323232', '234', 1, 1, '2022-11-17 09:57:05', NULL, '2022-11-17 09:57:05');

-- --------------------------------------------------------

--
-- Table structure for table `user_document_permission`
--

CREATE TABLE `user_document_permission` (
  `document_permission_id` int(11) DEFAULT NULL,
  `document_permission_group_id` int(11) DEFAULT NULL,
  `document_id` int(11) NOT NULL,
  `user_user_id` int(11) NOT NULL,
  `user_datetime_stamp` datetime DEFAULT NULL,
  `user_document_permission_status_id` int(11) NOT NULL,
  `user_document_permission_created_by` int(11) DEFAULT NULL,
  `user_document_permission_created_date` datetime NOT NULL DEFAULT current_timestamp(),
  `user_document_permission_modified_by` int(11) DEFAULT NULL,
  `user_document_permission_modified_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_group`
--

CREATE TABLE `user_group` (
  `user_group_id` int(11) NOT NULL,
  `user_group_name` varchar(250) DEFAULT NULL,
  `user_group_description` varchar(250) DEFAULT NULL,
  `is_root_user_group` tinyint(1) DEFAULT NULL,
  `user_date_created` datetime DEFAULT NULL,
  `user_group_status_id` int(11) DEFAULT NULL,
  `user_group_created_by` int(11) DEFAULT NULL,
  `user_group_created_date` int(11) NOT NULL DEFAULT current_timestamp(),
  `user_group_modified_by` int(11) DEFAULT NULL,
  `user_group_modified_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_role`
--

CREATE TABLE `user_role` (
  `id` int(25) NOT NULL,
  `name` varchar(250) DEFAULT NULL,
  `description` varchar(250) DEFAULT NULL,
  `status_id` int(15) DEFAULT NULL,
  `created_by` int(15) DEFAULT NULL,
  `created_date` datetime NOT NULL DEFAULT current_timestamp(),
  `modified_by` int(15) DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_role`
--

INSERT INTO `user_role` (`id`, `name`, `description`, `status_id`, `created_by`, `created_date`, `modified_by`, `modified_date`) VALUES
(1, 'Administrator', 'Administrator', 1, NULL, '2022-11-13 13:52:00', NULL, NULL),
(3, 'SuperUser', 'SuperUser', 1, NULL, '2022-11-13 13:52:30', NULL, NULL),
(5, 'User', 'User', 1, NULL, '2022-11-13 13:54:33', NULL, NULL),
(7, 'Document Owner', 'Document Owner', 1, NULL, '2022-11-13 13:54:58', NULL, NULL),
(9, 'Manager', 'Manager', 1, NULL, '2022-11-13 13:55:17', NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `document`
--
ALTER TABLE `document`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `document_permission`
--
ALTER TABLE `document_permission`
  ADD PRIMARY KEY (`document_permission_id`),
  ADD UNIQUE KEY `document_permission_name` (`document_permission_name`);

--
-- Indexes for table `document_taxonomy`
--
ALTER TABLE `document_taxonomy`
  ADD UNIQUE KEY `taxonomy_id` (`taxonomy_id`),
  ADD UNIQUE KEY `document_id` (`document_id`),
  ADD UNIQUE KEY `user_id` (`user_id`);

--
-- Indexes for table `file_type`
--
ALTER TABLE `file_type`
  ADD PRIMARY KEY (`file_type_id`);

--
-- Indexes for table `folder`
--
ALTER TABLE `folder`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `key_word`
--
ALTER TABLE `key_word`
  ADD PRIMARY KEY (`key_word_id`),
  ADD UNIQUE KEY `document_id` (`document_id`);

--
-- Indexes for table `my_favourite`
--
ALTER TABLE `my_favourite`
  ADD UNIQUE KEY `document_id` (`document_id`),
  ADD UNIQUE KEY `user_id` (`user_id`);

--
-- Indexes for table `taxonomy_level1`
--
ALTER TABLE `taxonomy_level1`
  ADD PRIMARY KEY (`Taxonomy_level1_id`),
  ADD UNIQUE KEY `Taxonomy_level1_name` (`Taxonomy_level1_name`),
  ADD UNIQUE KEY `created_by_id` (`created_by_id`),
  ADD UNIQUE KEY `Taxonomy_root_id` (`Taxonomy_root_id`);

--
-- Indexes for table `taxonomy_root`
--
ALTER TABLE `taxonomy_root`
  ADD PRIMARY KEY (`Taxonomy_root_id`),
  ADD UNIQUE KEY `Taxonomy_root_name` (`Taxonomy_root_name`),
  ADD UNIQUE KEY `created_by_id` (`created_by_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_id_4` (`id`),
  ADD KEY `user_id` (`id`),
  ADD KEY `user_id_2` (`id`),
  ADD KEY `user_id_3` (`id`);

--
-- Indexes for table `user_document_permission`
--
ALTER TABLE `user_document_permission`
  ADD UNIQUE KEY `document_id` (`document_id`),
  ADD UNIQUE KEY `document_permission_id` (`document_permission_id`),
  ADD UNIQUE KEY `document_permission_group_id` (`document_permission_group_id`),
  ADD KEY `user_user_id` (`user_user_id`);

--
-- Indexes for table `user_group`
--
ALTER TABLE `user_group`
  ADD PRIMARY KEY (`user_group_id`),
  ADD UNIQUE KEY `user_group_name` (`user_group_name`);

--
-- Indexes for table `user_role`
--
ALTER TABLE `user_role`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `document`
--
ALTER TABLE `document`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `folder`
--
ALTER TABLE `folder`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=82;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(25) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `user_role`
--
ALTER TABLE `user_role`
  MODIFY `id` int(25) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
